from telebot.types import ReplyKeyboardMarkup
from keep_alive import keep_alive
import telebot

keep_alive()

TOKEN = "7709509464:AAHQXAJkzYV1DvpXa5QWFDywlPjrSikjkTQ"
API_KEY = "e4VmlSRaf5qNYzSmHGl1lGrDbh6M4cxL"
ADMIN_ID = 8122016970

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start_handler(message):
    if message.chat.id == ADMIN_ID:
        bot.send_message(message.chat.id, "Welcome Admin!")
    else:
        bot.send_message(message.chat.id, "Hello! Contact @Sell_number_tg to recharge your balance.")

@bot.message_handler(commands=['add'])
def add_balance(message):
    if message.chat.id == ADMIN_ID:
        bot.send_message(message.chat.id, "Send the user ID to add balance to:")
        bot.register_next_step_handler(message, get_user_id)
    else:
        bot.send_message(message.chat.id, "Unauthorized.")

def get_user_id(message):
    user_id = message.text.strip()
    bot.send_message(message.chat.id, f"Balance added for user ID: {user_id} (simulation)")

bot.polling()